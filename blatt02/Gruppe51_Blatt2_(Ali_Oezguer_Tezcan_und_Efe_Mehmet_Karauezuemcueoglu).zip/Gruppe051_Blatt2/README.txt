script.py Datei ist bei uns ausführbar.
mit "python script.py beispiel.vhdl beispiel_tb.vhdl testbench.vcd"